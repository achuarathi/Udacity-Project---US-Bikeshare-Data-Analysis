# Udacity Feedback

## Criteria

Create a vis. to show the distribution of trip durations (histogram) for subscribers and customers. Describe the qualities of these distributions in report.

## Problems

* Could not find answer to question 5 (I didn't label this section very well because things started to overlap. (I actually combined the two histograms into a single one.)

* Make sure that only trips with a max duration of 75 mins are plotted with bins 5 minutes wide.

* Where is the peak of the distribution and what shape does the distribution have.

## Interpretation of the problems

Overall, it seems that I just didn't make this part of the report very clear so I should refactor the code and make things more explicit.
